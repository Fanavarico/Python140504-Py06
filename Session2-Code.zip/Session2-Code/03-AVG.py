num1=int(input('first: '))
num2=float(input('second:'))
num3=float(input('third: '))
s=num1+num2+num3
avg=s//3
print(avg)
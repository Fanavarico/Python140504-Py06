num1=float(input('first: '))
print(type(num1))
print(num1)
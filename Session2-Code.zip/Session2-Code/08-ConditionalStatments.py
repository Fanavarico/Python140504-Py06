i=int(input('enter number :'))
if i>0:
    print('POS')
elif i<0:
    print('NEG')
else:
    print('zero')
i=int(input('enter number :'))
if i>0:
    print('POS')
if i<=0:
    print('NEG')
if i==0:
    print('zero')
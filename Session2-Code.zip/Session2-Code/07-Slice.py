s='python language'
print(s[2:])

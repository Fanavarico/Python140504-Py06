s=int(input('enter number :'))
h=s//3600
s=s-(h*3600)
m=s//60
s=s-(m*60)
print(h,':',m,':',s)



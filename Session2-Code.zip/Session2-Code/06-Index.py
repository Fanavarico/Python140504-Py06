s=['y','ali',85,True,[5,'67']]
print(s[3])

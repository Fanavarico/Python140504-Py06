i=int(input('enter number: '))
if i%2==0:
    print('even')
elif i%2!=0:
    print('odd')

r=float(input('enter radius: '))
p=3.14
a=r*r*p
c=r*2*p
print('مساحت :',a)
print('محیط:',c)
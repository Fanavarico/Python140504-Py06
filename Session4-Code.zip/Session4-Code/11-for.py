for i in range(1,5):
    print()
    for j in range(2,5):
        print(i+1,end=' ')


s='AGHG'
print(help(s.isupper))

import random
h=random.randint(1, 10)
print(h)

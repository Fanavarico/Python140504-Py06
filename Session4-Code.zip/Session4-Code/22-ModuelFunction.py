import math
i=math.sqrt(4)
print(i)

s='67678h'
#i=s.islower()
#i=s.isupper()
i=s.isdigit()
print(i)

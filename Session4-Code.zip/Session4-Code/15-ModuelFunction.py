from datetime import datetime
u=datetime.now()
print(u)

s='79u'
#f=s.islower()
#f=s.isupper()
f=s.isdigit
print(f)

for i in range(1,4):
    print()
    for j in range(2,6):
        print(j,end=' ')
        
#2 3 4 5


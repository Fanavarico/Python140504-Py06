s=input('enter string: ')
for i in s:
    if i.isdigit():
        continue
    print(i)


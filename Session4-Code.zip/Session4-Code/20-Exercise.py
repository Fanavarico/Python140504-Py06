s=input('enter string:')
c=0
for i in s:
    if i.isdigit():
        c+=1

print(c)
        
for i in range(2,5):
    print()
    for j in range(1,i):
        print(j,end='')
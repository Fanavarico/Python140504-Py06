s=input('enter name: ')
for i in s:
    if i=='d' or i=='D':
        break
    print(i,end='+')


s=input('enter string: ')
c=0
for i in s:
    if i.isdigit():
        i=int(i)
        c=c+i
print(c)
        

s=input('enter string :')
for i in s:
    if i.isdigit()==True:
        print(i)


import random
h=random.choice(['sang','kaghaz','ghaychi'])
print(h)


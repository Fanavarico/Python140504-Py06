add1='C://Users//My Pc//Desktop//first//f.txt'
with open(add1) as f1:
    #t=f1.read(100)
    #for i in f1:
        #print(i)
    r=f1.readlines(6)
    print(r)

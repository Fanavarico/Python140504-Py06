def f()->str:
    a=input('enter string: ')
    b=int(input('enter start:'))
    c=int(input('enter end: '))
    return a[0:b]+a[c+1:]



g=f()
print(g)


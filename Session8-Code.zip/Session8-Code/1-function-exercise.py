def f(s:str,start:int,end:int)->str:
    if len(s)>end:
        return s[0:start]+s[end+1:]
    else:
        print('index end is not valid')


a=input('enter string: ')
b=int(input('enter start:'))
c=int(input('enter end: '))
g=f(a,b,c)
print(g)





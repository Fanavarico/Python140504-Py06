f=open('C://Users//My Pc//Desktop//first//z.py')
g=f.read()
print(g)
f.close()



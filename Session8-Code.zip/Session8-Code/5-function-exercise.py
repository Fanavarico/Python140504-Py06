def f(lst):
    r=[]
    for i in lst:
        if i not in r:
            r.append(i)
    print(r)

h=[]
while True:
    i=input('enter:')
    if i=='exit':
        break
    else:
        h.append(int(i))
f(h)
lst=['yes','yes','no','yes']
add1='C://Users//My Pc//Desktop//first//f.txt'
with open (add1,'w') as f1:
    for i in lst:
        f1.write(i)
        f1.write('\n')

d={}        
with open (add1,'r') as f2:
    l=f2.readlines()
    print(l)
    for j in l:
        j=j.strip()
        if j in d.keys():
            d[j]+=1
        elif j not in d.keys():
            d[j]=1
            
print(d)
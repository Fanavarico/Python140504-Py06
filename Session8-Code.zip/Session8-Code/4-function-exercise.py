def f(s):
    r=''
    for i in range(len(s)):
        if i % 2 == 1:
            r+=s[i]
    print(r)


f('python')
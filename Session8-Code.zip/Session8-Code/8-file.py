add1='C://Users//My Pc//Desktop//first//f.txt'
with open(add1,'w') as f1:
    for i in range(3):
        s=input('enter :')
        f1.write(s)
        f1.write('\n')
    

add1='C://Users//My Pc//Desktop//first//f.txt'
with open(add1) as f1:
    for i in f1:

        r=f1.readline()
        print(r)


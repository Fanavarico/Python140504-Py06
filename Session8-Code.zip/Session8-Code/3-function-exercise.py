def f(s):
    return s[1: :2]

print(f('python'))
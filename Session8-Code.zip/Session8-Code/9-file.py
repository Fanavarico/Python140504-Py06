add1='C://Users//My Pc//Desktop//first//f.txt'
with open(add1,'w') as f1:
    while True:
        s=input('enter : ')
        if s=='exit':
            break
        else:
            f1.write(s)
            f1.write('\n')
l=['a','a','b','c','b','a']
d={}
'''for i in l:
    if i in d.keys():
        d[i]=d[i]+1
    elif i not in d.keys():
        d[i]=1

        '''
for i in l:
    d[i]=d.get(i,0)+1
    
print(d)
#d={'a':3,'b':2,'c':1}

l=[14,8,7,12,18,20, 6, 7]
s=[i if i<10 else i>17 for i in l]
print(s)

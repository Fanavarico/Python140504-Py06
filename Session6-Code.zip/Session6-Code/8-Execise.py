t=(100,300)
t1=(7,90)
l=list(t)
l1=list(t1)
p=[]
for i in t:
    for j in t1:
        p.append(i+j)

print(tuple(p))


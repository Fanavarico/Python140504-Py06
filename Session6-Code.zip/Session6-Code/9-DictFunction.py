d={'name':'a','family':'b','class':8,'name':'r'}
#print(d)
#print(type(d))
#print(len(d))
#d['class']=90
#print(d)
#v=d.get('family1','not found')
#v=d.values()
#k=d.keys()
#print(k)
#print(type(k))
'''
i=d.items()
print(i)
print(type(i))
for i,j in d.items():
    print(i,':',j)
v=d.pop('family')  
print(v)
print(d)
v=d.popitem()
print(v)
print(d)'''













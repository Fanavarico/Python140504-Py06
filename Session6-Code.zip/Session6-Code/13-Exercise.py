s=input('enter string : ')
f=s.split()
#print(f)
d={}
'''
for i in f:
    if i in d:
        d[i]+=1
    elif i not in d:
        d[i]=1
'''
for i in f:
    d[i]=d.get(i,0)+1
print(d)

t=('apple','grape','Apple','orange','apple')
'''print(t[2])
print(type(t))
print(t[2:4])
for i in t:
    print(i)
for i in range(0,5):
    print(i+1,t[i])
i=t.count('apple')
print(i)
i=t.index('Apple1')
print(i)
r=('hello',)
print(type(r))
t1=(1,2)
t2=(2,1)
print(t1==t2)
t1=(1,2)
t2=(200,100)
print(t2+t1)
t2=(200,100)
r=list(t2)
#r.append('hello')
n=('hello',500)
r.extend(n)
t2=tuple(r)
print(t2)
t2=(200,100)
l=list(t2)
l.remove(100)
#print(l)
t=tuple(l)
print(t)
#a,b,c=[700,6,40]
#a,b,c='reza','ali','hassan'
#a,b,c='ali'
a,b,c=(700,6,40)
print('a',a)
print('b',b)
print('c',c)'''
a=90,6,'ali'
print(type(a))





























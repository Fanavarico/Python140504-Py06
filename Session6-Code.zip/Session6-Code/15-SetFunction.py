s={'apple','grape','apple','Apple','orange'}
s1={'grape','grape','apple','orange','Apple'}
#print(s)
#print(type(s))
#print(len(s))
#print(s==s1)
'''for i in s:
    print(i)
s.add('cherry')
print(s)
s.update(['mango','cherry'])
print(s)
s.remove('applea')
print(s)
s.discard('applea')
print(s)'''
t={1,4}
t1={8,4}
'''i=t.union(t1)
print(i)
print(t|t1)
i=t.intersection(t1)
print(i)
print(t&t1)
print(t-t1)'''
print(t1-t)












l=[999,800,600,500]
for i,j,k in l:
    print(i,':',j,':',k)
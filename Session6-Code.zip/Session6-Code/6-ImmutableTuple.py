t=(9,7)
t[1]=600
print(t)


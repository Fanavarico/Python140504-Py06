d={'d':12,'a':90,'s':2}
c=0
'''for i in d.values():
    c=c+i
print(c)'''
for i in d:
    c=c+d[i]
print(c)
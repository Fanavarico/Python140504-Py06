x=2
y=x
y+=1
print(x)
print(y)
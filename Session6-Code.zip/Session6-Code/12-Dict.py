d={'name':'a','family':'b'}
d['class']=90
print(d)
v=d.get('name1','not found')
print(v)
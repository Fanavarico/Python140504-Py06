l=['$ali','reza$']
s=[i.strip('$') for i in l ]
print(s)

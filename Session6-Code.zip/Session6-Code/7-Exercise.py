l=[4,5,('a',),40,70,('ali',80)]
for i in l:
    if type(i)==tuple:
        print(i)
x=[]
y=x
y.append(6)
print(x)
print(y)
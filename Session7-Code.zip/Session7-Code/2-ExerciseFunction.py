p=3.14

def mo(r):
    result=2*p*r
    #print('mohit',result)
    print(f'mohit: {result:.2f}')


def ma(r):
    result=p*r*r
    #print('masahat',int(result))
    print(f'masahat: {result:.2f}')


def main():
    a=float(input('enter radius: '))
    c=input('select mohit or masahat: ')
    if c=='mohit':
        mo(a)
    elif c=='masahat':
        ma(a)
main()

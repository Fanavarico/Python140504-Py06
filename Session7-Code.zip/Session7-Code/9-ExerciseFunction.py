g={'a':40,'b':8}
def f(d):
    d['a']+=1
    d['b']-=1
    print(d.keys())
    

f(g)
print(g['a'])
print(g['b'])
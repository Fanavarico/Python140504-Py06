
def f(a):
    a[0]+=1
    a[1]-=1

l=[12,3]
f(l)
print(l[0])
print(l[1])
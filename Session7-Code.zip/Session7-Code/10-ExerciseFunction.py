def f(a,b=90):
    a+=1
    b-=1
    return a, b

a=19
b=80
print(f())
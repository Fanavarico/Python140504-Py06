'''a,b={14:1,15:12}
print('a',a)
print('b',b)'''
def f(a,b):
    a+=1
    b-=1
    return a,b

m,n=f(6,12)
print('m:',m)
print('n:',n)


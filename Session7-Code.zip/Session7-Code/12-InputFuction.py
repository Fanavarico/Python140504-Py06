def f(**t):
    print(t)
    print(type(t))
    
f()
f(name='a')
f(family='b',n='a')
f(f='a',b='d',c='k')
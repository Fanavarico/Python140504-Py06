x=float(input('first: '))
y=float(input('second: '))
z=float(input('third: '))
t=float(input('forth: '))

for i in range(1,5):
    pass
def m(a,b):
    if a>b:
        return a
    else:
        return b
    

def g(d,h,i,k):
    j=m(d,i)
    u=m(j,k)
    return m(h,u)

f=g(z,x,y,t)
print(f)

    
    
    
    
    
    
    
    
def f(*t):
    print(t)
    print(type(t))
    
f()
f(9)
f(0,7)
f(7,'ali',7)

'''def f(a,b,*more):
    print(a,b,more)
    

f(3,6)
f(4,8,9)'''

def f(a,b,*m,**t):
    print(a,b,m,t)
    
f(9,8)
f(4,8,9)
f(8,9,7,6,5,n=90)
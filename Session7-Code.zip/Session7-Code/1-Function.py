"""def hello():
    print('welcome')


hello()

def hello(a:int)->None:
    '''این تابع یک ورودی دارد'''
    print('welcome',a)


b=input('enter name: ')    
hello(5)

def hello():
    return 'welcome'

l=hello()
print(l)
print(hello())

def hello(a:str)->tuple:
    return 'welcome ',a


b=input('enter name: ')
f=hello(b)
print(type(f))
"""
def sum1(a,b):
    print('a',a)
    print('b',b)
    print(a+b)
    
    
    
sum1('20','hello')


































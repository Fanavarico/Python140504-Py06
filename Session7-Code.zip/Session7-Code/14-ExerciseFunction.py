stu=[{'id':60,'m':19,'f':14},\
     {'id':690,'m':9,'f':18}]
    
#{'id':60,'avg':16.5}

def f(a):
    k=[]
    for i in a:
        f=i.pop('f')
        u=i.pop('m')
        i['avg']=(f+u)/2
        k.append(i)
        #print(i)
    print(k)
        
f(stu)

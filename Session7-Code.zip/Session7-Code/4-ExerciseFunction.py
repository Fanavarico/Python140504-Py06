
def m():
    a=float(input('first: '))
    b=float(input('second: '))
    if a>b:
        return a
    else:
        return b
    
f=m()
print(f)
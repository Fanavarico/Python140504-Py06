l=[]
for i in range(1,5):
    x=float(input('first: '))
    l.append(x)
    
def m(a,b):
    if a>b:
        return a
    else:
        return b
    

def g(l):
    j=m(l[0],l[1])
    u=m(j,l[2])
    return m(u,l[3])

f=g(l)
print(f)

    
    
    
    
    
    
    
    
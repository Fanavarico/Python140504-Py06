p=3.14
def mo(r):
    '''محاسبه محیط'''
    #p=7
    result=2*p*r
    print(p)
    #print('mohit',result)
    print(f'mohit: {result:.2f}')


def ma(r):
    #p=15
    result=p*r*r
    print(p)
    #print('masahat',int(result))
    print(f'masahat: {result:.2f}')


def main():
    a=float(input('enter radius: '))
    c=input('select mohit or masahat: ')
    if c=='mohit':
        mo(a)
    elif c=='masahat':
        ma(a)
main()

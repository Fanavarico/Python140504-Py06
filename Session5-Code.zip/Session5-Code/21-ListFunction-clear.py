l=['hello',90,'hi']
l.clear()
print(l)
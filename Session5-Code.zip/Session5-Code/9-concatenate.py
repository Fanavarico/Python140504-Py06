print(5+9)
print('5'+'9')
print([8,'i']+[6,'hello'])
print('5',9)
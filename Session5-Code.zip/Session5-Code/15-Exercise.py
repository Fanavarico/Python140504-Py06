l=[]
while True:
    i=input('enter : ')
    if i=='exit':
        break
    l.append(i)



print(l)
        
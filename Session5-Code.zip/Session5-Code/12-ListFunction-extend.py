l=[8,'y']
l.extend(['hello',7])
print(l)
print(len(l))
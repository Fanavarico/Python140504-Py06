l=['hello',90,'hi']
del l[1]
print(l)

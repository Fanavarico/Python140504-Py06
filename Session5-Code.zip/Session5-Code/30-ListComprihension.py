l=[8,5,13,12,20,6]
#for i in l:
#    if i<10:
#        print(i)

l=[i for i in l if i<10 elif i<12]
print(l)
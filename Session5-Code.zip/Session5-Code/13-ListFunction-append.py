l=[8,'y']
l.append(['hello',7])
print(l)
print(len(l))

l=[]
for i in range(1,6):
    i=input('enter : ')
    l.append(i)
    
print(l)

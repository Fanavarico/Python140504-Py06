s='hello'
s[1]='iiii'
print(s)
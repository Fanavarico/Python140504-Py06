l=['hello',90,'hi']
#print(l[2][1])
l[0]='salam'
print(l)

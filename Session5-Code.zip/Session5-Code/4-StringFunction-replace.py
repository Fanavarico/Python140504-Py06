s='pythony'
d=s.replace('y', 'i',1)
print(d)
n=input('enter').split()

i=input('enter : ')
if i==i[::-1]:
    print(True)
else:
    print(False)
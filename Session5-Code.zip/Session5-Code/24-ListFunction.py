l=['hello',90,'hi']
#i=l.count(900)
#i=l.index(900)
#l.insert(2, 'ddgd')
#r=l.pop(1)
#l.remove(90)
l.reverse()
print(l)
#print(r)
radar

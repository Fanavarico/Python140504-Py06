s=['python', 'is', 'programming', 'language']
d='*'.join(s)
print(d)

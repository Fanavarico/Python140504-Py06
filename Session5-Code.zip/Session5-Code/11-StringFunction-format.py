r='refrandom'
y=2020
#print('result of {} in {}'.format(r,y))
print('result of {r} in {y}'.format(r='refrandom', y=2026))
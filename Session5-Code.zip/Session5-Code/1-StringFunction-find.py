s='python is progrsmming language'
#f=s.find('i',9,17)
f=s.index('i',9,17)
print(f)
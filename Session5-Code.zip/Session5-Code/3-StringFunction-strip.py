s='    python   '
d=s.strip()
#d=s.rstrip('$')
#d=s.lstrip('$')
#d=s.lstrip('#').rstrip('$')
print(d)

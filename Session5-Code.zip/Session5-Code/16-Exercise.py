s=['hj','hgh',90]
for i in range(len(s)):
    print(s[i])
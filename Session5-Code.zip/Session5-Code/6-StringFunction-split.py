s='python is progrsmming language'
l=s.split(' ')
print(l)

s='py$$$thon$'
t=s.replace('$', '')
print(t)

l=['hello',90,'hi']
j=l.copy()
l.append(87)
print(j)
print(l)


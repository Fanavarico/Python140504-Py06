a,b=90,5
print(a)
print(b)
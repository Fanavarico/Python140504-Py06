#l=[i for i in range(1,6)]
#l=[i*2 for i in range(1,6)]
#l=[input('enter') for i in range(1,6)]
#l=[ for i in range(1,6) input('enter')]

names=input('enter : ').split()
#l=[name for name in names ]
l=[]
for name in names:
    l.append(name)
print(l)

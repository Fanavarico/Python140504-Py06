s='ali\nreza'
print(s.split())
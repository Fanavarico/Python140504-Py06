l=[]
while True:
    i=input('enter : ')
    i=i.strip()
    if i.lower()=='exit':
        break
    if i.isdigit():
        i=int(i)
        l.append(i)


print(l)
        

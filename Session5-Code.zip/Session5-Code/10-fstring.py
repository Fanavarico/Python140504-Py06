r='refrandom'
y=2020
s=f'result of {r} in {y}'
print(s)

#import item
from item import Product
#y=item.Product(50, 'n1', 10, 400)
#y=Product(10, 'n1', 40, 500)
#print(y)
class manage:
    def __init__(self):
        self.items={}
    def create_item(self,id_i,n1,nu,pr):
        new_item=Product(id_i, n1, nu, pr)
        return new_item
    def add_items(self,item):
        if item.id_p not in self.items:
            self.items[item.id_p]=item
            print('added')
            print(self.items)
        else:
            print('exist')
    def remove_item(self,id_i):
        if id_i in self.items:
            del self.items[id_i]
            print('deleted')
            print(self.items)
        else:
            print('not exit')
    def display_item(self,id_i):
        if id_i in self.items:
            print(self.items[id_i])
            
    def edit_item(self,id_i):
        if id_i in self.items:
            new_na=input('enter new name:')
            new_nu=input('enter new number')
            new_pr=input('enter new price:')
            self.items[id_i].name=new_na or self.items[id_i].name
            self.items[id_i].num=int(new_nu or self.items[id_i].num)
            self.items[id_i].price=int(new_pr or self.items[id_i].price)
        else:
            print('not exist')


m1=manage()
t=m1.create_item(40, 'tshirtk', 50, 100)
t1=m1.create_item(41, 'tshirt', 50, 100)
t2=m1.create_item(42, 'tshirtm', 50, 100)
m1.add_items(t)
m1.add_items(t1)
m1.add_items(t2)
#m1.remove_item(40)
m1.edit_item(40)
m1.display_item(40)

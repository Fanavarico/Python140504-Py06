class Cart:
    def __init__(self,balance):
        self.b=balance
        
    def withdraw(self,amount):
        if self.b<amount:
            print('موجودی کافی نیست')
        elif self.b>=amount:
            self.b-=amount
            return self.b
    
    def deposite(self,amount):
        self.b+=amount
        return self.b
meli=Cart(1000)
melat=Cart(40)
print(f'mojodi kart meli {meli.deposite(400)}')
melat.withdraw(100)
meli.deposite(100)
meli.withdraw(40)
print(melat.b)

class cart:
balance=0
def withdraw(amount):
    global balance
    if balance<amount:
        print('موجودی کافی نیست')
    elif balance>=amount:
        balance-=amount
        print('موجودی',balance)

def deposite(amount):
    global balance
    balance+=amount
    print('موجودی',balance)

deposite(900)
withdraw(100)        
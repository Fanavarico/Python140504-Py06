class Product:
    def __init__(self,id_p,name,num,price):
        self.id_p=id_p
        self.name=name
        self.num=num
        self.price=price
    def __str__(self):
        return f'id:{self.id_p} , name:{self.name},\
              num:{self.num} ,price{self.price}'
              
if "__main__" ==__name__:             
    p1=Product(40, 'Tshirt', 40, 4000)
    print(p1)
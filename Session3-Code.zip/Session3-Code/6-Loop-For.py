l=[12,5,'ali',80.5,True]
c=1
for i in l:
    c+=1
    print(c,'-',i)
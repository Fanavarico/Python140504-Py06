a=int(input('سن خود را وارد کنید: '))
g=input('جنسیت را وارد کنید : ')
if g=='m':
    if a>=0 and a<=40:
        print('پسر')
    elif a>=40 and a<=60:
        print('پدر')
    elif a>=60:
        print('پدربزرگ')
elif g=='f':
    if a>=0 and a<=40:
        print('دختر')
    elif a>=40 and a<=60:
        print('مادر')
    elif a>=60:
        print('مادربزرگ')


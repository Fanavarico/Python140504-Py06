a=int(input('سن خود را وارد کنید: '))
g=input('جنسیت را وارد کنید : ')
if g=='m' and a<=40 and a>=0:
    print('پسر')
elif g=='m' and 40<=a<=60:
    print('پدر')
elif g=='m' and a>=60:
    print('پدربزرگ')
elif g=='f' and a<=40 and a>=0:
    print('دختر')
elif g=='f' and a>=40 and a<=60:
    print('مادر')
elif g=='f' and a>=60:
    print('مادربزرگ')
    